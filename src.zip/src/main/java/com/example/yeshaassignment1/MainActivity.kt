package com.example.yeshaassignment1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import android.os.PersistableBundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    val FILE_NAME: String = "com.example.yeshaassignment1.myPreferenceFile";

    private fun increment(name : String):Int{
        val sharedPreference =  getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
        var editor = sharedPreference.edit()
        var methodCount=sharedPreference.getInt(name,0);
        methodCount++;
        editor.putInt(name,methodCount);
        editor.apply()

        return methodCount;
    }

    private fun onReset(){
        val FILE_NAME = "com.example.yeshaassignment1.myPreferenceFile"
        val sharedPreference =  getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
        var editor = sharedPreference.edit()
        editor.clear()
        editor.apply()
        var resetval = 0
        onCreateCount.setText(": "+resetval.toString())
        onRestartCount.setText(": "+resetval.toString())
        onStartCount.setText(": "+resetval.toString())
        onPauseCount.setText(": "+resetval.toString())
        onStopCount.setText(": "+resetval.toString())
        onDestroyCount.setText(": "+resetval.toString())
        onResumeCount.setText(": "+resetval.toString())
        onSaveCount.setText(": "+resetval.toString())
        onRestoreCount.setText(": "+resetval.toString())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var count=increment("onCreate");
        val FILE_NAME = "com.example.yeshaassignment1.myPreferenceFile"
        val sharedPreference =  getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
        onCreateCount.text = sharedPreference.getInt("onCreate", 0).toString()
        onRestartCount.text = sharedPreference.getInt("onRestart", 0).toString()
        onStartCount.text = sharedPreference.getInt("onStart", 0).toString()
        onPauseCount.text = sharedPreference.getInt("onPause", 0).toString()
        onResumeCount.text = sharedPreference.getInt("onResume", 0).toString()
        onDestroyCount.text = sharedPreference.getInt("onDestroy", 0).toString()
        onStopCount.text = sharedPreference.getInt("onStop", 0).toString()
        onSaveCount.text = sharedPreference.getInt("onSave", 0).toString()
        onRestoreCount.text = sharedPreference.getInt("onRestore", 0).toString()

        //Printing bundle values
        Log.i("Bundle value:",savedInstanceState?.getInt("onCreate", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onRestart", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onStart", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onPause", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onSave", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onRestore", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onResume", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onDestroy", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onStop", 0).toString())

        reset.setOnClickListener{ onReset() }
    }

    override fun onRestart() {
        super.onRestart()
        var count=increment("onRestart")
        onRestartCount.setText(": "+count.toString())
        Log.i("Result","onRestart(): $count")
    }

    override fun onStart() {
        super.onStart()
        var count=increment("onStart")
        onStartCount.setText(": "+count.toString())
        Log.i("Result","onStart(): $count")
    }

    override fun onPause() {
        super.onPause()
        var count=increment("onPause")
        onPauseCount.setText(": "+count.toString())
        Log.i("Result","onPause(): $count")

    }

    override fun onStop() {
        super.onStop()
        var count=increment("onStop")
        onStopCount.setText(": "+count.toString())
        Log.i("Result","onStop(): $count")
    }

    override fun onDestroy() {
        super.onDestroy()
        var count=increment("onDestroy")
        onDestroyCount.setText(": " +count.toString())
        Log.i("Result","onDestroy(): $count")
    }

    override fun onResume() {
        super.onResume()
        var count=increment("onResume")
        onResumeCount.setText(": "+count.toString())
        Log.i("Result","onResume(): $count")
    }

    override fun onSaveInstanceState(outState: Bundle?) {
        val FILE_NAME = "com.example.yeshaassignment1.myPreferenceFile"
        val sharedPreference =  getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)
        var count=increment("onSave")
        onSaveCount.setText(": " +count.toString())
        Log.i("Result","onSave(): $count ")

        outState?.putInt(onCreateRow.toString(), sharedPreference.getInt("onCreate", 0))
        outState?.putInt(onRestartRow.toString(), sharedPreference.getInt("onRestart",0))
        outState?.putInt(onStartRow.toString(), sharedPreference.getInt("onStart",0))
        outState?.putInt(onPauseRow.toString(), sharedPreference.getInt("onPause",0))
        outState?.putInt(onSaveRow.toString(), sharedPreference.getInt("onSave",0))
        outState?.putInt(onRestoreRow.toString(), sharedPreference.getInt("onRestore",0))
        outState?.putInt(onStopRow.toString(), sharedPreference.getInt("onStop",0))
        outState?.putInt(onDestroyRow.toString(), sharedPreference.getInt("onDestroy",0))
        outState?.putInt(onResumeRow.toString(), sharedPreference.getInt("onResume",0))

        super.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle?) {
        super.onRestoreInstanceState(savedInstanceState)

        //Printing Bundle values
        Log.i("Bundle value:",savedInstanceState?.getInt("onCreate", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onRestart", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onStart", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onPause", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onSave", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onRestore", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onResume", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onDestroy", 0).toString())
        Log.i("Bundle value:",savedInstanceState?.getInt("onStop", 0).toString())


        var count=increment("onRestore")
        onRestoreCount.setText(": " +count.toString())
        Log.i("Result","onRestore(): $count")

    }
}
